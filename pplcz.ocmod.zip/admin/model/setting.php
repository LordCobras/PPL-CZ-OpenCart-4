<?php
namespace Opencart\Admin\Model\Extension\Pplcz;

require_once  __DIR__ . '/../../autoload.php';

class Setting extends \PPLCZ\Repository\Setting
{
}